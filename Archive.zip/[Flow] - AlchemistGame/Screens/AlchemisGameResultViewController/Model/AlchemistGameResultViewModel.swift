//
//  AlchemistGameResultViewModel.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 20.05.2024.
//

import Foundation

struct AlchemistGameResultViewModel {
    let inventions: String
    let iconName: [String]
    let selectedElementCountTitle: String
    let infoLabel: String
    let restartButtonTitle: String
}
