//
//  AlchemistGameResultInteractor.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 20.05.2024.
//

import Foundation

protocol AlchemistGameResultInteractorProtocol {
    func viewDidLoad()
    func didTapRestartButton()
}

protocol AlchemistGameResultInteractorCoordinatorDelegate: AnyObject {
    func didTapRestartButton()
}

final class AlchemistGameResultInteractor {
    
    private let presenter: AlchemistGameResultPresenterProtocol
    private var selectedInventions: Inventions
    private var selectedIconName: [String]
    weak var coordinator: AlchemistGameResultInteractorCoordinatorDelegate?
    
    init(presenter: AlchemistGameResultPresenterProtocol, selectedInventions: Inventions, selectedIconName: [String]) {
        self.presenter = presenter
        self.selectedInventions = selectedInventions
        self.selectedIconName = selectedIconName
    }
}

extension AlchemistGameResultInteractor: AlchemistGameResultInteractorProtocol {
    
    func viewDidLoad() {
        presenter.presentAlchemistGameResult(inventions: self.selectedInventions, iconName: self.selectedIconName)
    }
    
    func didTapRestartButton() {
        self.selectedInventions = .none
        self.selectedIconName.removeAll()
        coordinator?.didTapRestartButton()
    }
}
