//
//  AlchemistGameResultViewController+Build.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 20.05.2024.
//

import Foundation
import UIKit

extension AlchemistGameResultViewController {
    static func build(coordinator: AlchemistGameResultInteractorCoordinatorDelegate, selectedInventions: Inventions, selectedIconName: [String]) -> UIViewController {
        let presenter = AlchemistGameResultPresenter()
        let interactor = AlchemistGameResultInteractor(presenter: presenter, selectedInventions: selectedInventions, selectedIconName: selectedIconName)
        interactor.coordinator = coordinator
        let viewController = AlchemistGameResultViewController(interactor: interactor)
        presenter.viewController = viewController
        return viewController
    }
}
