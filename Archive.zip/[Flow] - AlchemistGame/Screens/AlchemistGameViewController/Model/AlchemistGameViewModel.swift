//
//  AlchemistGameViewModel.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 20.05.2024.
//

import Foundation

struct AlchemistGameViewModel {
    let elementTitle: String
    let combineButtonTitle: String
}
