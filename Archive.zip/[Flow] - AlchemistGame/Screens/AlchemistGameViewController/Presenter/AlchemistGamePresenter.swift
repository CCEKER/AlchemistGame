//
//  AlchemistGamePresenter.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 15.05.2024.
//

import Foundation

protocol AlchemistGamePresenterProtocol {
    func presentElements(_ elements: [Elements])
}

final class AlchemistGamePresenter: AlchemistGamePresenterProtocol {
    
    
    weak var viewController: AlchemistGameViewControllerProtocol?
    
    func presentElements(_ elements: [Elements]) {
        viewController?.displayElements(elements)
    }
}
