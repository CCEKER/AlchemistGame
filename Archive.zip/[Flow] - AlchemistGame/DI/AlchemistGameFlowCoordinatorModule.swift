//
//  AlchemistGameFlowCoordinatorModule.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 15.05.2024.
//

import Foundation
import Swinject

protocol AlchemistGameFlowCoordinatorResolver {
    func resolveAlchemistGameViewController(delegate: AlchemistGameInteractorCoordinatorDelegate) -> UIViewController
    func resolveAlchemistGameResultViewController(delegate: AlchemistGameResultInteractorCoordinatorDelegate, selectedInventions: Inventions, selectedIconName: [String]) -> UIViewController
}

final class AlchemistGameFlowCoordinatorModule: AlchemistGameFlowCoordinatorResolver {
    
    private let container: Container
    private let resolver: Resolver
    
    init(parentContainer: Container) {
        container = Container(parent: parentContainer)
        _ = Assembler([AlchemistGameFlowCoordinatorAssembly()], container: container)
        self.resolver = container
    }
    
    func resolveAlchemistGameViewController(delegate: AlchemistGameInteractorCoordinatorDelegate) -> UIViewController {
        let elementService = resolver.resolve(ElementServiceProtocol.self)!
        return AlchemistGameViewController.build(coordinator: delegate, elementService: elementService)
    }
    
    func resolveAlchemistGameResultViewController(delegate: AlchemistGameResultInteractorCoordinatorDelegate, selectedInventions: Inventions, selectedIconName: [String]) -> UIViewController {
        AlchemistGameResultViewController.build(coordinator: delegate, selectedInventions: selectedInventions, selectedIconName: selectedIconName)
    }
}
