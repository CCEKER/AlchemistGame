//
//  ApplicationFlowCoordinatorAssembly.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 15.05.2024.
//

import Foundation
import Swinject

final class ApplicationFlowCoordinatorAssembly: Assembly {
    
    func assemble(container: Container) {
        // ..
    }
}
