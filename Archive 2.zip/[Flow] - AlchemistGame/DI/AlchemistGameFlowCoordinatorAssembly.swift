//
//  AlchemistGameFlowCoordinatorAssembly.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 15.05.2024.
//

import Foundation
import Swinject

final class AlchemistGameFlowCoordinatorAssembly: Assembly {
    
    func assemble(container: Container) {
        // ...
    }
}
