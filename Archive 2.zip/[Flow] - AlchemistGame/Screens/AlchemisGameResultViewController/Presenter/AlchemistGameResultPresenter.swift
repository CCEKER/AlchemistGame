//
//  AlchemistGameResultPresenter.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 20.05.2024.
//

import Foundation

protocol AlchemistGameResultPresenterProtocol {
    func presentAlchemistGameResult(inventions: Inventions, iconName: [String])
}

final class AlchemistGameResultPresenter: AlchemistGameResultPresenterProtocol {
    
    weak var viewController: AlchemistGameResultViewControllerProtocol?
    
    func presentAlchemistGameResult(inventions: Inventions, iconName: [String]) {
        let viewModel = AlchemistGameResultViewModel(
            inventions: inventions.rawValue,
            iconName: iconName,
            selectedElementCountTitle: "You chose \(iconName.count) elements!",
            infoLabel: "You've made a",
            restartButtonTitle: "Restart"
        )
        viewController?.displayViewModel(viewModel)
    }
}
