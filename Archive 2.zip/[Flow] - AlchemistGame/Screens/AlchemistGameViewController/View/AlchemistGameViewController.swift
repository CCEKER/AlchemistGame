//
//  AlchemistGameViewController.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 15.05.2024.
//

import UIKit

protocol AlchemistGameViewControllerProtocol: AnyObject {
    func displayElements(_ element: [Elements])
}

class AlchemistGameViewController: UIViewController, AlchemistGameCollectionViewCellDelegate {
    
    private let customView = AlchemistGameView()
    private let interactor: AlchemistGameInteractorProtocol
    private var elements: [Elements] = []
    var selectedElements: [Elements] = []
    
    init(interactor: AlchemistGameInteractorProtocol) {
        self.interactor = interactor
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func loadView() {
        view = customView
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Alchemist Game"
        
        customView.combineButton.addTarget(self, action: #selector(didTapCombineButton), for: .touchUpInside)
        
        customView.collectionView.delegate = self
        customView.collectionView.dataSource = self
        
        interactor.viewDidLoad()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.selectedElements = []
        updateCombineButtonState()
    }
    
    @objc private func didTapCombineButton() {
        interactor.didTapCombine(elements: selectedElements)
        resetViews()
    }
    
    func updateViewSelectionState(_ cell: AlchemistGameCollectionViewCell, elementName: Elements, isSelected: Bool) {
        if isSelected {
            selectedElements.append(elementName)
        } else {
            if let index = selectedElements.firstIndex(of: elementName) {
                selectedElements.remove(at: index)
            }
        }
        updateCombineButtonState()
    }
    
    private func resetViews() {
        for cell in customView.collectionView.visibleCells as! [AlchemistGameCollectionViewCell] {
            cell.resetViews()
        }
    }
    
    private func updateCombineButtonState() {
        customView.combineButton.isEnabled = selectedElements.count > 1
        customView.combineButton.alpha = selectedElements.count > 1 ? 1.0 : 0.5
    }
}

extension AlchemistGameViewController: AlchemistGameViewControllerProtocol {
    
    func displayElements(_ element: [Elements]) {
        self.elements = element
        customView.collectionView.reloadData()
    }
}

extension AlchemistGameViewController: UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! AlchemistGameCollectionViewCell
        cell.delegate = self
        let element = elements[indexPath.row]
        cell.reloadWith(element)
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        CGSize(width: (view.frame.width - 150) / 2, height: 162)
    }
}
