//
//  AlchemistGameInteractor.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 15.05.2024.
//

import Foundation

protocol AlchemistGameInteractorProtocol {
    func viewDidLoad()
    func didTapCombine(elements: [Elements])
}

protocol AlchemistGameInteractorCoordinatorDelegate: AnyObject {
    func didTapCombineButton(element: Inventions, selectedIconName: [String])
}

final class AlchemistGameInteractor {
    
    private let presenter: AlchemistGamePresenterProtocol
    weak var coordinator: AlchemistGameInteractorCoordinatorDelegate?
    private let elementService: ElementServiceProtocol
    private var selectedElements: [Elements] = []
    private var selectedInovations: Inventions?
    
    init(presenter: AlchemistGamePresenterProtocol, elementService: ElementServiceProtocol) {
        self.presenter = presenter
        self.elementService = elementService
    }
}

extension AlchemistGameInteractor: AlchemistGameInteractorProtocol {
    
    func viewDidLoad() {
        let elements = [
            Elements.air,
            Elements.earth,
            Elements.fire,
            Elements.water
        ]
        presenter.presentElements(elements)
    }
    
    func didTapCombine(elements: [Elements]) {
       
        let result = elementService.getResult(input: elements)
        guard let result else { return }
        let selectedIconName = elements.map { $0.returnString() }
        coordinator?.didTapCombineButton(element: result, selectedIconName: selectedIconName)
    }
}
