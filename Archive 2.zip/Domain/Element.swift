//
//  Element.swift
//  AlchemistGame
//
//  Created by Cagatay Ceker on 16.05.2024.
//

import Foundation

enum Elements: Comparable {
   
    case fire
    case water
    case air
    case earth
    
    func returnString() -> String {
        switch self {
        case .fire:
            return "Fire"
        case .water:
            return "Water"
        case .air:
            return "Air"
        case .earth:
            return "Earth"
        }
    }
}

enum Inventions: String {
    case steam = "Steam"
    case smoke = "Smoke"
    case lava = "Lava"
    case mud = "Mud"
    case rain = "Rain"
    case dust = "Dust"
    case volcano = "Volcano"
    case plant = "Plant"
    case acidRain = "Acid Rain"
    case none
}
